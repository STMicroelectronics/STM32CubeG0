/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G05x devices support on MDK-ARM.
  ************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************
  

Running the "Keil.STM32G05x_DFP.0.0.2.pack" adds the following:
  
1. Part numbers for  :
 - Product lines: STM32G051x8xx/STM32G051x6xx/STM32G051x4xx/STM32G061x8xx/STM32G061x6xx/STM32G061x4xx
 - Value Line:    STM32G050x6xx/STM32G050x8xx
  
2. Automatic STM32G05x flash algorithm selection 
    
3. SVD file.


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32G05x_DFP.0.0.2.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE************************





	



