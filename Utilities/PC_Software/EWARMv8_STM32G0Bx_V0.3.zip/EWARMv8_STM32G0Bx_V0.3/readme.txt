/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G0Bx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************

These packages contains the needed files to be installed in order to support STM32G0Bx 
devices by EWARM8 and laters.

1. If you have already installed an STM32G0Bx patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2. Running the "EWARMv8_STM32G0Bx_V0.3.exe" adds the following:
=====================================================================
- Part Numbers with 512KB Flash size: STM32G0B1xE/STM32G0C1xE
- Part Numbers with 256KB Flash size: STM32G0B1xC/STM32G0C1xC
- Part Numbers with 128KB Flash size: STM32G0B1xB
- Value Line STM32G0B0xE with 512KB Flash size
- Automatic STM32G0Bx flash algorithm selection
- SVD files 
 

How to use:
===========
* Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32G0Bx_V0.3.exe" as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \", 

******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE*************************





	



